# GitHub Copilot Instructions
# Read on EVERY suggestion. Keep this file current with your project.

## The 5-Agent System
Only invoke @00-orchestrator. It delegates to the others automatically.

| Agent | Purpose | When it runs |
|-------|---------|-------------|
| 00-orchestrator       | Entry point, gap analysis, pipeline control | Always — you invoke this |
| 01-stepdef-generator  | Creates missing StepDef methods            | Auto — when StepDefs missing |
| 02-steps-page-generator| Creates missing Step + Page methods       | Auto — when Steps/Pages missing |
| 03-self-healer        | Fixes broken locators from DOM            | Auto — on NoSuchElement errors |
| 04-test-runner        | Runs affected scenarios, reports results  | Auto — after each generation |

---

## Your Project Structure
# ⚠️ UPDATE THIS SECTION to match your actual project layout

StepDefs location : src/test/java/stepdefs/
Steps location    : src/test/java/steps/[domain]/
Pages location    : src/test/java/pages/[domain]/
Features location : src/test/resources/features/[module]/
Queries location  : src/test/resources/queries/
Config            : src/test/resources/serenity.conf

---

## Your Existing Classes
# ⚠️ LIST YOUR EXISTING CLASSES HERE so agents never recreate them

CommonStepDefs steps already implemented:
  - "the user is on the {string} page"        → navigateToPage()
  - "the user is logged in as {string}"       → loginAs()
  - "a success message {string} should be displayed" → verifySuccessMessage()
  - "an error message {string} should be displayed"  → verifyErrorMessage()

Existing step libraries (DO NOT recreate, only add to):
  - steps/common/CommonUISteps.java
  - steps/common/CommonDbSteps.java
  - steps/common/CommonApiSteps.java
  # Add your domain step libraries here as you create them

Existing page objects (DO NOT recreate, only add to):
  - pages/common/LoginPage.java
  # Add your page objects here as you create them

---

## Code Rules — EVERY Agent Must Follow These

ALWAYS:
  ✅ WebElementFacade — never raw WebElement
  ✅ Serenity waitFor() — never Thread.sleep()
  ✅ SerenityRest.given() — never RestAssured.given()
  ✅ QueryLoader.load("file.sql") — never inline SQL
  ✅ @Step on every step library method
  ✅ AssertJ with .as("failure message") on every assertion
  ✅ automation_ prefix on all generated test data emails
  ✅ Check CommonStepDefs before writing any @Given/@When/@Then

NEVER:
  ❌ Duplicate a step text already in CommonStepDefs
  ❌ Write logic in StepDef classes — delegation only
  ❌ Write assertions in Page Object classes
  ❌ Hardcode URLs — always serenity.conf pages block
  ❌ Hardcode credentials — always environment variables
  ❌ Recreate a class that already exists — only ADD to it

---

## Locator Strategy — Always This Priority
1. data-testid   → @FindBy(css = "[data-testid='xxx']")
2. Unique id     → @FindBy(id = "xxx")
3. Name attr     → @FindBy(css = "input[name='xxx']")
4. Stable class  → @FindBy(css = ".semantic-class")
5. XPath         → LAST RESORT + add: // TODO: request data-testid

---

## Self-Healing Trigger Words
When error contains any of these → automatically call @03-self-healer:
  - NoSuchElementException
  - TimeoutException: Expected condition failed
  - Element not found
  - Unable to locate element
  - StaleElementReferenceException

When error contains these → DO NOT call healer, it's a code/logic issue:
  - AssertionError
  - NullPointerException
  - CompilationError
  - UndefinedStepException
