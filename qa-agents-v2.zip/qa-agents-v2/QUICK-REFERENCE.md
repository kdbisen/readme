# 🚀 Quick Reference — 5-Agent Smart Orchestration

## You Only Ever Type ONE Thing

```
@00-orchestrator

[paste your feature file content]

My project layout:
- StepDefs : src/test/java/stepdefs/
- Steps    : src/test/java/steps/[domain]/
- Pages    : src/test/java/pages/[domain]/
```

That's it. The orchestrator handles the rest.

---

## The 4 Situations You'll Be In

### Situation 1 — New feature file
```
@00-orchestrator

[paste feature file — any number of scenarios]
```
→ Creates all missing StepDefs, Steps, Pages
→ Runs all scenarios
→ Reports pass/fail

---

### Situation 2 — Updated existing feature file
```
@00-orchestrator

Updated feature file:
[paste feature file]

Changed: Scenario "Login with MFA" (new step added)
```
→ Only generates what's NEW or CHANGED
→ Doesn't touch existing working scenarios
→ Runs only affected scenarios

---

### Situation 3 — Test failed, element not found
```
@00-orchestrator

Test failed:
[paste stack trace]

DOM of the page at failure:
[paste HTML from Chrome DevTools → right-click → Inspect → copy outer HTML of the form/section]

Feature file:
[paste feature file]

Current Page Object:
[paste Page Object .java file]
```
→ Self-healer identifies broken locator
→ Shows you the exact line to change
→ Re-runs the scenario after fix

---

### Situation 4 — Run one scenario after I edited a file
```
@00-orchestrator

Run this after my changes:
Scenario: [exact scenario name]
Feature: [path/to/file.feature]
```
→ Gives you exact Maven command
→ Interprets the result
→ Tells you next action if it fails

---

## What Each Agent Actually Does

```
00-orchestrator       ← YOU talk to this. It reads your feature file,
                         finds gaps, builds the plan, delegates.

01-stepdef-generator  ← Takes your step texts (@Given/@When/@Then),
                         creates the Java glue methods. Thin delegation only.

02-steps-page-generator← Takes the delegation targets, creates the @Step
                         methods and Page Object locators/actions.

03-self-healer        ← Takes error + DOM + broken Page Object,
                         finds the right locator in your live DOM.

04-test-runner        ← Takes scenario name, gives you the mvn command,
                         reads the output, explains pass/fail clearly.
```

---

## Important Notes

**Multiple scenarios in one feature file** — works fine.
The orchestrator processes ALL scenarios in one pass and deduplicates
shared steps so you never get duplicate StepDef methods.

**Scenario Outlines** — works fine.
One set of methods is generated for the template.
The Examples table data is handled by Cucumber automatically.

**Already have code?** — works fine.
Add your existing classes to copilot-instructions.md.
Agents will only ADD to existing classes, never overwrite.

**DOM for healing** — Chrome DevTools shortcut:
  Right-click the broken element → Inspect
  Right-click the highlighted HTML → Copy → Copy outer HTML
  Paste it to the orchestrator

---

## Files in This Package

```
.github/
├── agents/
│   ├── 00-orchestrator.md          ← Entry point
│   ├── 01-stepdef-generator.md     ← StepDefs from feature steps
│   ├── 02-steps-page-generator.md  ← Steps + Page Objects
│   ├── 03-self-healer.md           ← Fixes broken locators
│   └── 04-test-runner.md           ← Runs tests, reports results
└── copilot-instructions.md         ← Always-on rules (update with YOUR classes)
```

Copy the `.github/` folder into your project root. Done.
