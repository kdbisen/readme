# 🚀 Developer Agents — Quick Reference

## You Always Type ONE Thing

```
@00-dev-orchestrator

[unit tests / documentation / both]

[paste your Java class here]
```

---

## 3 Commands. That's It.

```
# Unit tests only
@00-dev-orchestrator  unit tests  [paste class]

# Documentation only
@00-dev-orchestrator  documentation  [paste class]

# Both
@00-dev-orchestrator  unit tests and documentation  [paste class]
```

---

## What You Get Back

### Unit Tests
```
src/test/java/[your/package]/[ClassName]Test.java
  - Happy path test per public method
  - Edge case tests (null, empty, boundary)
  - Exception tests
  - Parameterized tests for data-driven scenarios
  - Correct mocks for your dependencies
  - Named: method_shouldOutcome_whenCondition()
```

### Documentation
```
Javadoc blocks → paste into your .java file
  - Class-level: what it does, why it exists, usage example
  - Method-level: @param, @return, @throws for every public method
  - Inline comments: only where logic is non-obvious

README section → paste into your README.md or wiki
  - Plain English description
  - Key methods table
  - Usage example
  - Dependencies table
```

---

## Multiple Files at Once

```
@00-dev-orchestrator  unit tests and documentation

FILE 1: UserService.java
[paste]

FILE 2: OrderProcessor.java
[paste]

FILE 3: PaymentGateway.java
[paste]
```

Generates one test file and one README section per class.

---

## Files

```
.github/
├── agents/
│   ├── 00-dev-orchestrator.md      ← Start here
│   ├── 01-unit-test-generator.md   ← Unit tests
│   └── 02-doc-generator.md         ← Documentation
└── copilot-instructions.md         ← Always-on rules
```
