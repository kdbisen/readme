# GitHub Copilot Instructions — Developer Agents
# Read on every suggestion. Update when your stack changes.

## The 3-Agent System for Developers

| Agent | Purpose | When to use |
|-------|---------|-------------|
| `00-dev-orchestrator`   | Entry point — detects what you need | Always start here |
| `01-unit-test-generator`| Reads class → creates test file     | After completing a class |
| `02-doc-generator`      | Reads class → creates Javadoc + README | After completing a class |

---

## Your Tech Stack
# ⚠️ UPDATE to match your project

Language      : Java 11+
Build         : Maven / Gradle
Test Framework: JUnit 5
Mock Library  : Mockito
Assertions    : AssertJ
Spring Boot   : [Yes/No]
Architecture  : [Layered / Hexagonal / MVC / etc.]

---

## Test File Convention
Source:  src/main/java/[package]/[ClassName].java
Test:    src/test/java/[package]/[ClassName]Test.java
(Mirror the package structure — always)

---

## Documentation Convention
Javadoc  : inline in .java file
README   : paste into README.md under ## Components section
Wiki     : paste into Confluence / internal wiki if applicable

---

## Rules — Unit Tests
- NEVER test simple getters/setters
- NEVER mock what you can instantiate cheaply
- ALWAYS use AAA pattern: Arrange / Act / Assert
- ALWAYS name tests: [method]_should[Outcome]_when[Condition]
- ALWAYS assert with AssertJ .as("message") for clear failure output
- ALWAYS verify mock interactions when side effects matter
- ONE assertion concept per test (multiple assertThat lines are fine
  if they all verify the same logical outcome)

---

## Rules — Documentation
- ALWAYS explain WHY, not just WHAT
- NEVER state the obvious in comments
- ALWAYS include a usage example in class-level Javadoc
- ALWAYS document @throws for checked and meaningful unchecked exceptions
- NEVER add inline comments to self-explanatory code
- ALWAYS document null behaviour for params and return values
