# Serenity BDD AI Agent

A GitHub Copilot Custom Agent (`@serenity-ai`) that stores Serenity BDD reports per release and
answers natural-language QA queries from IntelliJ's Copilot Chat panel.

> **Full implementation details, code, and Serenity JSON reference → see `SKILL.md`**

---

## What it can do

| Query (type in Copilot Chat) | What you get |
|---|---|
| `@serenity-ai summary for v2.5.0` | Pass / fail / pending counts |
| `@serenity-ai how many tests failed in v2.5.0?` | Failure count + list of failed tests |
| `@serenity-ai show failed test cases in v2.5.0` | **Full detail per failed test — name, duration, error message, stack hint, grouped by feature** |
| `@serenity-ai compare v2.4.1 vs v2.5.0` | Side-by-side table + new failures + fixed tests |
| `@serenity-ai what new failures appeared in v2.5.0?` | Tests that regressed since previous release |
| `@serenity-ai why did CheckoutFlowTest fail in v2.5.0?` | Full error message + stack trace + failed steps |
| `@serenity-ai is the pass rate improving over last 3 releases?` | Trend across N versions |

**Yes — release comparison is fully supported.** The agent fetches both `summary.json` files
from the `/reports/` folder, diffs the `testResults[]` arrays, and returns a markdown table
with delta counts, new failures, and fixed tests. No extra token cost for the comparison itself
— it is computed in the agent's Node.js logic, not by the LLM.

---

## How reports are stored

CI publishes Serenity JSON output into a versioned folder after every run:

```
reports/
  v2.4.1/summary.json   ← aggregate counts + per-test results
  v2.4.1/results/       ← individual test JSON files
  v2.5.0/summary.json
  v2.5.0/results/
```

The GitHub Actions step that does this is in `SKILL.md → Phase 1`.

---

## Setup (3 steps)

1. **Store reports** — add the GitHub Actions step from `SKILL.md → Phase 1` to your CI workflow.
2. **Deploy the agent server** — `npm install && node index.js` — see `SKILL.md → Phase 2` for
   the full server code and `.env` variables needed.
3. **Register the GitHub App** — create a Copilot Extension on github.com, point the webhook at
   your server — see `SKILL.md → Phase 3`.

After that, `@serenity-ai` is available in IntelliJ's Copilot Chat panel.

---

## Token usage — keeping it lean

| File | Read by | Token strategy |
|---|---|---|
| `agent.md` (this file) | Humans | Minimal — no code blocks, just intent + pointers |
| `SKILL.md` | AI / Copilot | Full code + JSON reference, loaded on demand |

`agent.md` intentionally contains **no code**. All implementation is in `SKILL.md` so Copilot
only pays the token cost when it actually needs to generate or extend the agent.

---

## Files in this project

```
serenity-agent/
├── agent.md          ← this file (lightweight human guide)
├── SKILL.md          ← full AI instructions + all code
├── index.js          ← Express server entry point
├── handlers/
│   ├── compare.js    ← compare two releases
│   ├── failures.js   ← show failed test case details (grouped by feature)
│   ├── query.js      ← route single-release questions
│   └── trend.js      ← trend across N releases
└── lib/
    ├── github.js     ← fetch summary.json from GitHub API
    ├── parser.js     ← normalise Serenity JSON fields
    └── prompt.js     ← optional LLM root-cause prompts
```
