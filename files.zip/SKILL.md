---
name: serenity-bdd-ai-agent
description: >
  Use this skill whenever the user wants to build, extend, or understand a GitHub Copilot
  Custom Agent (Extension) for querying Serenity BDD test reports. Triggers include: storing
  Serenity reports across releases, comparing test results between versions, asking AI questions
  about failures/pass rates/regression, building a @copilot-agent in IntelliJ, or any workflow
  that connects Serenity BDD output to GitHub Copilot Chat. Also trigger when the user asks
  about parsing serenity summary.json, setting up GitHub Actions to publish reports, or writing
  agent logic to answer natural-language QA queries.
---

# Serenity BDD AI Agent Skill

This skill guides you through building a **GitHub Copilot Custom Agent** that stores Serenity BDD
reports per release, compares them, and answers natural-language questions from IntelliJ's
Copilot Chat panel using `@serenity-ai` (or any chosen handle).

---

## Architecture at a glance

```
CI Pipeline
  └─► Serenity report (JSON + HTML)
        └─► GitHub Actions (parse + commit)
              └─► /reports/<version>/summary.json  (in GitHub repo)
                    └─► Custom Agent API  (Node.js / Python)
                          └─► AI Logic (compare JSONs, build LLM prompt)
                                └─► GitHub Copilot Chat (@serenity-ai in IntelliJ)
```

---

## Phase 1 — Report Storage

### 1.1  What to store

Serenity outputs these key files after every run:

| File | Purpose |
|---|---|
| `target/site/serenity/summary.json` | Aggregate totals: pass, fail, pending, skipped |
| `target/site/serenity/results/*.json` | Per-test detail: name, result, error message, duration |
| `target/site/serenity/index.html` | Human-readable HTML report (optional to store) |

**Store at minimum:** `summary.json` + `results/` folder.

### 1.2  Folder convention in the repo

```
reports/
  v2.4.1/
    summary.json
    results/
  v2.5.0/
    summary.json
    results/
  latest -> v2.5.0   (symlink or copy)
```

### 1.3  GitHub Actions step

Add this job to your existing CI workflow after the Serenity test step:

```yaml
# .github/workflows/publish-report.yml
- name: Publish Serenity report to repo
  if: always()                        # run even when tests fail
  run: |
    VERSION="${{ github.ref_name }}"  # e.g. v2.5.0, or use $GITHUB_SHA for commit-level
    mkdir -p reports/$VERSION/results
    cp target/site/serenity/summary.json reports/$VERSION/summary.json
    cp target/site/serenity/results/*.json reports/$VERSION/results/
    git config user.email "ci-bot@yourorg.com"
    git config user.name  "CI Bot"
    git add reports/
    git diff --cached --quiet || git commit -m "chore: serenity report $VERSION"
    git push
```

> **Tip:** If your test repo and reports repo are separate, use `GITHUB_TOKEN` with a PAT that has `contents:write` on the reports repo.

---

## Phase 2 — Custom Agent API

### 2.1  What a GitHub Copilot Extension is

A Copilot Extension = a **GitHub App** with:
- A webhook endpoint your server exposes
- The `copilot_extensions` permission
- Installed on your org so members can use `@agent-name` in Copilot Chat

### 2.2  Project structure

```
serenity-agent/
  index.js          ← Express server, main entry point
  handlers/
    compare.js      ← Compare two release summaries
    failures.js     ← Show failed test case details (grouped by feature)
    query.js        ← Route single-release questions
    trend.js        ← Trend across N releases
  lib/
    github.js       ← Fetch summary.json from GitHub API
    parser.js       ← Normalise Serenity JSON structure
    prompt.js       ← Build LLM prompts for root-cause queries
  .env              ← GITHUB_TOKEN, APP_SECRET, REPO_OWNER, REPO_NAME
  package.json
```

### 2.3  Core server (index.js)

```js
import express from 'express';
import { verifySignature } from './lib/auth.js';
import { handleQuery } from './handlers/query.js';
import { handleCompare } from './handlers/compare.js';

const app = express();
app.use(express.json());

app.post('/agent', verifySignature, async (req, res) => {
  const message = req.body.messages.at(-1).content;
  const isCompare = /compare|vs|versus|difference|delta/i.test(message);
  const versions = message.match(/v?\d+\.\d+[\.\d]*/g) ?? [];

  try {
    const reply = isCompare && versions.length >= 2
      ? await handleCompare(versions[0], versions[1])
      : await handleQuery(message, versions[0] ?? 'latest');

    res.json({ role: 'assistant', content: reply });
  } catch (err) {
    res.json({ role: 'assistant', content: `⚠️ Error: ${err.message}` });
  }
});

app.listen(3000, () => console.log('Serenity agent running on :3000'));
```

### 2.4  Fetch report from GitHub (lib/github.js)

```js
import { Octokit } from '@octokit/rest';

const octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });

export async function fetchSummary(version) {
  const path = `reports/${version}/summary.json`;
  const { data } = await octokit.repos.getContent({
    owner: process.env.REPO_OWNER,
    repo:  process.env.REPO_NAME,
    path,
  });
  return JSON.parse(Buffer.from(data.content, 'base64').toString('utf8'));
}

export async function fetchTestDetail(version, testFileName) {
  const path = `reports/${version}/results/${testFileName}`;
  const { data } = await octokit.repos.getContent({
    owner: process.env.REPO_OWNER,
    repo:  process.env.REPO_NAME,
    path,
  });
  return JSON.parse(Buffer.from(data.content, 'base64').toString('utf8'));
}
```

### 2.5  Compare handler (handlers/compare.js)

```js
import { fetchSummary } from '../lib/github.js';

export async function handleCompare(v1, v2) {
  const [s1, s2] = await Promise.all([fetchSummary(v1), fetchSummary(v2)]);

  const newFails = (s2.testResults ?? []).filter(t =>
    t.result === 'FAILURE' &&
    !(s1.testResults ?? []).some(f => f.name === t.name && f.result === 'FAILURE')
  );

  const fixed = (s1.testResults ?? []).filter(t =>
    t.result === 'FAILURE' &&
    (s2.testResults ?? []).some(f => f.name === t.name && f.result !== 'FAILURE')
  );

  return `## Release comparison: ${v1} → ${v2}

| Metric       | ${v1}           | ${v2}           | Δ |
|--------------|-----------------|-----------------|---|
| Total        | ${s1.total}     | ${s2.total}     | ${s2.total - s1.total} |
| Passed       | ${s1.counts?.SUCCESS ?? 0} | ${s2.counts?.SUCCESS ?? 0} | ${(s2.counts?.SUCCESS ?? 0) - (s1.counts?.SUCCESS ?? 0)} |
| Failed       | ${s1.counts?.FAILURE ?? 0} | ${s2.counts?.FAILURE ?? 0} | ${(s2.counts?.FAILURE ?? 0) - (s1.counts?.FAILURE ?? 0)} |
| Pending      | ${s1.counts?.PENDING ?? 0} | ${s2.counts?.PENDING ?? 0} | — |

### 🔴 New failures in ${v2} (${newFails.length})
${newFails.length
  ? newFails.map(t => `- **${t.name}**: \`${t.testFailureCause?.message ?? 'see report'}\``).join('\n')
  : '_No new failures — good job!_'}

### ✅ Fixed in ${v2} (${fixed.length})
${fixed.length
  ? fixed.map(t => `- ${t.name}`).join('\n')
  : '_No tests fixed between these releases._'}`;
}
```

### 2.6  Single-release query handler (handlers/query.js)

Routes each natural-language question to the right logic block.

```js
import { fetchSummary } from '../lib/github.js';
import { showFailures } from './failures.js';

export async function handleQuery(message, version) {
  const summary = await fetchSummary(version);
  const failures = (summary.testResults ?? []).filter(t => t.result === 'FAILURE');

  // "show failed", "list failures", "see failed test cases", "failed report"
  if (/show|list|see|display|view/i.test(message) && /fail/i.test(message)) {
    return showFailures(failures, version);
  }

  // "how many failed", "count failures", "failure count"
  if (/how many|count|number of/i.test(message) && /fail/i.test(message)) {
    return `**${version}** had **${failures.length} failing tests** out of ${summary.total} total.\n\n` +
      failures.slice(0, 10).map(t => `- ${t.name}`).join('\n') +
      (failures.length > 10 ? `\n_...and ${failures.length - 10} more._` : '');
  }

  // "why did X fail", "reason for failure", "error in X"
  if (/why|reason|cause|error/i.test(message)) {
    const testName = extractTestName(message);
    const match = failures.find(t => t.name.toLowerCase().includes(testName.toLowerCase()));
    if (match) {
      return formatSingleFailure(match, version);
    }
    return `Could not find a test matching "${testName}" in ${version}. Try a partial name.`;
  }

  // Default: release summary
  return `**${version} summary:**
- Total: ${summary.total}
- Passed: ${summary.counts?.SUCCESS ?? 0}
- Failed: ${summary.counts?.FAILURE ?? 0}
- Pending: ${summary.counts?.PENDING ?? 0}
- Skipped: ${summary.counts?.IGNORED ?? 0}`;
}

function extractTestName(message) {
  const match = message.match(/["'](.+?)["']|test\s+(\S+)/i);
  return match?.[1] ?? match?.[2] ?? '';
}

function formatSingleFailure(test, version) {
  const steps = (test.testSteps ?? [])
    .filter(s => s.result === 'FAILURE')
    .map(s => `  - Step: ${s.description}\n    Error: ${s.errorMessage ?? 'N/A'}`)
    .join('\n');

  return `## ${test.name}
**Release:** ${version}
**Result:** FAILURE
**Duration:** ${(test.duration / 1000).toFixed(2)}s
**Feature:** ${test.featureTag ?? test.tags?.find(t => t.type === 'feature')?.name ?? 'N/A'}

### Error message
\`\`\`
${test.testFailureCause?.message ?? 'No error message recorded'}
\`\`\`

### Stack trace (top 3 lines)
\`\`\`
${(test.testFailureCause?.stackTrace ?? []).slice(0, 3).join('\n') || 'N/A'}
\`\`\`

### Failed step(s)
${steps || '_No step-level detail available_'}`;
}
```

### 2.7  Failed test cases detail handler (handlers/failures.js)

This is the dedicated handler for **"show me the failed test cases"** queries.
It reads from `summary.json` (which already contains `testResults[]` with error data)
and formats a rich markdown report grouped by feature tag.

```js
// handlers/failures.js

export function showFailures(failures, version) {
  if (!failures.length) {
    return `✅ No failing tests found in **${version}**.`;
  }

  // Group by feature tag for easier scanning
  const grouped = {};
  for (const t of failures) {
    const feature = t.tags?.find(tag => tag.type === 'feature')?.name ?? 'Untagged';
    if (!grouped[feature]) grouped[feature] = [];
    grouped[feature].push(t);
  }

  const sections = Object.entries(grouped).map(([feature, tests]) => {
    const rows = tests.map((t, i) => {
      const error = t.testFailureCause?.message ?? 'No error captured';
      const duration = t.duration ? `${(t.duration / 1000).toFixed(2)}s` : 'N/A';
      const stack = t.testFailureCause?.stackTrace?.[0] ?? '';
      return [
        `#### ${i + 1}. ${t.name}`,
        `- **Duration:** ${duration}`,
        `- **Error:** \`${error.slice(0, 120)}${error.length > 120 ? '…' : ''}\``,
        stack ? `- **At:** \`${stack}\`` : '',
      ].filter(Boolean).join('\n');
    });

    return `### Feature: ${feature} (${tests.length} failure${tests.length > 1 ? 's' : ''})\n\n${rows.join('\n\n')}`;
  });

  return [
    `## Failed test cases — ${version}`,
    `**Total failures: ${failures.length}**`,
    '',
    sections.join('\n\n---\n\n'),
    '',
    `_Ask \`@serenity-ai why did <test name> fail in ${version}?\` for full stack trace of any test above._`,
  ].join('\n');
}
```

**Sample output in Copilot Chat:**

```
## Failed test cases — v2.5.0
**Total failures: 3**

### Feature: Checkout (2 failures)

#### 1. CheckoutFlowTest should complete purchase
- Duration: 3.42s
- Error: `Expected <200> but was <500>`
- At: `com.example.CheckoutTest.checkStatus(CheckoutTest.java:42)`

#### 2. CheckoutFlowTest should apply discount code
- Duration: 1.10s
- Error: `Element not found: #discount-input`
- At: `com.example.CheckoutTest.applyDiscount(CheckoutTest.java:88)`

---

### Feature: Login (1 failure)

#### 1. LoginTest should reject invalid password
- Duration: 0.85s
- Error: `AssertionError: Expected false but was true`
- At: `com.example.LoginTest.verifyRejection(LoginTest.java:55)`

_Ask `@serenity-ai why did LoginTest fail in v2.5.0?` for full stack trace._
```

---

## Phase 3 — Register as GitHub Copilot Extension

### 3.1  Create the GitHub App

1. Go to **GitHub → Settings → Developer Settings → GitHub Apps → New GitHub App**
2. Fill in:
   - **App name:** `serenity-ai`
   - **Webhook URL:** `https://your-server.com/agent`
   - **Webhook secret:** generate a strong secret, store in `.env` as `APP_SECRET`
3. Permissions needed:
   - `Repository contents` → Read
   - `Copilot Chat` → Read and write (under **Account permissions**)
4. Under **Copilot**, set agent type to **"Copilot Extension"**
5. Install the app on your org

### 3.2  Deploy the agent server

Deploy as a simple Node.js service. Options:
- **GitHub Actions** — run as a long-lived workflow (not ideal)
- **Railway / Render / Fly.io** — free tier works for internal tools
- **Your org's internal VM** — if firewall allows inbound HTTPS from GitHub

Minimum `.env`:
```
GITHUB_TOKEN=ghp_xxxx
APP_SECRET=your_webhook_secret
REPO_OWNER=your-org
REPO_NAME=serenity-reports
```

---

## Phase 4 — Usage in IntelliJ

### 4.1  Open Copilot Chat

In IntelliJ: **Tools → GitHub Copilot → Open Copilot Chat** (or the chat icon in the sidebar).

### 4.2  Query examples

```
@serenity-ai how many tests failed in v2.5.0?

@serenity-ai compare v2.4.1 vs v2.5.0

@serenity-ai what new failures appeared in v2.5.0?

@serenity-ai why did CheckoutFlowTest fail in v2.5.0?

@serenity-ai show top failing categories in v2.5.0

@serenity-ai is the failure rate improving across the last 3 releases?
```

---

## Supported query types

| Intent | Trigger keywords | Handler |
|---|---|---|
| **Show failed test details** | "show failed", "list failures", "see failed test cases", "view failures" | `failures.js` |
| Failure count | "how many failed", "count failures" | `query.js` |
| Single test detail | "why did X fail", "reason", "error", "cause" | `query.js` |
| Release compare | "compare", "vs", "difference", "delta" | `compare.js` |
| New regressions | "new failures", "newly failing" | `compare.js` |
| Fixed tests | "fixed", "resolved", "now passing" | `compare.js` |
| Release summary | "summary", "overview", "status" | `query.js` |
| Trend | "trend", "improving", "over releases" | `trend.js` |

---

## Serenity JSON structure reference

Serenity's `summary.json` key fields:

```json
{
  "total": 120,
  "counts": {
    "SUCCESS": 98,
    "FAILURE": 15,
    "PENDING": 5,
    "IGNORED": 2
  },
  "testResults": [
    {
      "name": "CheckoutFlowTest should complete purchase",
      "result": "FAILURE",
      "duration": 3420,
      "tags": [{ "name": "checkout", "type": "feature" }],
      "testFailureCause": {
        "message": "Expected <200> but was <500>",
        "stackTrace": ["com.example.CheckoutTest.checkStatus(CheckoutTest.java:42)"]
      }
    }
  ]
}
```

> **Note:** Field names may vary slightly depending on Serenity version. Always validate against your actual output before building the parser.

---

## Extension points

- **LLM root-cause analysis:** Pass `testFailureCause.message` + stack trace to the GitHub Models API (or Claude) for a plain-English explanation of why a test failed.
- **Slack notifications:** Trigger a Slack message when new failures are detected on merge to main.
- **Historical trend handler:** Fetch the last N `summary.json` files and plot pass rate over time as a markdown table.
- **Tag/feature filtering:** Serenity tags tests by feature/story — extend the query parser to answer "how many checkout-tagged tests failed in v2.5.0?".
