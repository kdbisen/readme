# Copilot Instructions — Serenity Report Analysis

When I ask ANY question about Serenity BDD test reports, read the JSON files at
`serenity-reports/<version>/summary.json` in this project. Read the actual file before
answering — never guess counts or results. Answer any question derivable from the data,
not just the examples below.

## summary.json structure

- `total` — total test count
- `counts` — { SUCCESS, FAILURE, PENDING, IGNORED }
- `testResults[]` — each has:
  - `name`, `result` (SUCCESS|FAILURE|PENDING|IGNORED), `duration` (ms)
  - `tags[]` — { name, type }; "feature"/"story" types group tests
  - `testSteps[]` — { description, result, errorMessage }
  - `testFailureCause` — { message, stackTrace[] }

## How to answer

- Counts/rates: read `counts`; pass rate = SUCCESS / total * 100.
- Failed tests: list FAILURE results grouped by feature tag, with error, duration, first stack line.
- Why X failed: show testFailureCause message, top stack lines, failed steps, brief cause.
- Compare two versions: match tests by name across both files; show counts table with deltas,
  new failures (failing now but not before), and fixed tests.
- Trends (3+ versions): read each version's counts; show pass rate or failure count per version;
  find tests failing repeatedly across releases.
- Flaky tests: flag tests whose result changes across versions without intent.
- Performance: sort by duration for slowest; sum duration for total time; filter by threshold.
- Feature breakdown: group tests by feature tag; rank features by failure count.
- Search/lookup: find a test by name, report its result; filter by name substring; list versions.

Convert durations ms→seconds. Use markdown tables for comparisons and rankings.
If a version folder doesn't exist, say so and list the versions that do exist.
