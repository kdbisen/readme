# Serenity BDD Report Analyzer — Local Copilot Setup

A GitHub Copilot agent skill that reads your **local** Serenity BDD reports and answers
questions about failures, comparisons, and reasons — directly inside IntelliJ's Copilot Chat.

**No server. No downloads. No network. No exposed repos.** Copilot reads the JSON files
straight from your open project.

> How Copilot reads the reports → `.github/skills/serenity-analyzer/SKILL.md`

---

## Why this approach (and not the webhook one)

The old "@serenity-ai webhook extension" needs a public server — blocked in your org.
This version uses **Copilot Agent Skills**, which run entirely inside IntelliJ. Copilot
already sees every file in your open project, so it just reads the report JSON directly.
Nothing leaves your machine.

---

## What it can do

The skill teaches Copilot to answer **any** question derivable from your report data —
the list below is a sample, not a limit.

| Category | Example questions in Copilot Chat |
|---|---|
| **Counts & rates** | "how many failed in v2.5.0?" · "what's the pass rate?" · "full summary of v2.5.0" |
| **Failed details** | "show failed test cases in v2.5.0" · "which Checkout tests failed?" · "most common error?" |
| **Root cause** | "why did CheckoutFlowTest fail?" · "which step failed in LoginTest?" |
| **Compare versions** | "compare v2.4.1 and v2.5.0" · "what new failures appeared?" · "what got fixed?" |
| **Trends** | "is the pass rate improving over last 3 releases?" · "which tests fail repeatedly?" |
| **Flaky tests** | "is LoginTest flaky?" · "which tests are unstable across versions?" |
| **Performance** | "which tests are slowest?" · "total execution time?" · "tests over 5 seconds?" |
| **Feature breakdown** | "which feature has most failures?" · "pass/fail per feature" |
| **Search & lookup** | "did CheckoutTest pass in v2.5.0?" · "find tests matching 'login'" · "list all tests" |

If you ask something not in this list, Copilot works out which fields answer it, reads the
file, and computes the result — it's not limited to fixed scenarios.

---

## One-time setup (3 steps, all local)

1. **Put reports in your project.** Save each Serenity run into a versioned folder
   inside the project:

   ```
   your-project/
     serenity-reports/
       v2.4.1/summary.json
       v2.5.0/summary.json
   ```

   After `mvn verify`, just copy `target/site/serenity/summary.json` into the right folder.

2. **Add the skill.** Place the `.github/skills/serenity-analyzer/` folder (with its
   `SKILL.md`) at your project root. Copilot picks it up automatically.

3. **Enable Agent mode.** In IntelliJ: `Settings → GitHub Copilot → Chat → Agent`,
   turn on Agent Skills (public preview). Make sure your Copilot plugin is up to date.

That's it. Open Copilot Chat in Agent mode and ask away.

---

## Two ways Copilot can read your reports

| Method | File | Best for |
|---|---|---|
| **Agent Skill** | `.github/skills/serenity-analyzer/SKILL.md` | Auto-loads only when you ask about reports — keeps context lean |
| **Always-on instructions** | `.github/copilot-instructions.md` | Simpler, but loaded into every chat (more tokens) |

The skill approach is recommended — it only activates when relevant, so it costs no
extra tokens on unrelated chats. A ready-to-use `copilot-instructions.md` is included
below as a fallback if your Copilot version doesn't yet support skills.

---

## Fallback: copilot-instructions.md

If Agent Skills aren't available in your Copilot version, create
`.github/copilot-instructions.md` with this content:

```
When I ask about Serenity test reports, read the JSON files in the
serenity-reports/<version>/summary.json folders of this project.

Each summary.json has: total, counts {SUCCESS, FAILURE, PENDING, IGNORED},
and testResults[] with name, result, duration, tags[], and testFailureCause
{message, stackTrace[]}.

For failure counts, count testResults where result is FAILURE.
For comparisons, match tests by name across two version files and report
new failures, fixed tests, and the count deltas.
For "why did X fail", show the testFailureCause message and stack trace.
Always read the actual file before answering — never guess.
```

---

## Files in this setup

```
your-project/
├── agent.md                                  ← this guide (read once)
├── serenity-reports/                         ← your local reports, by version
│   ├── v2.4.1/summary.json
│   └── v2.5.0/summary.json
└── .github/
    ├── copilot-instructions.md               ← optional always-on fallback
    └── skills/
        └── serenity-analyzer/
            └── SKILL.md                       ← how Copilot reads the reports
```
