---
name: serenity-report-analyzer
description: >
  Use this skill whenever the user asks ANY question about Serenity BDD test reports stored
  locally in the project — counts, failures, reasons, comparisons, durations, trends, flaky
  tests, feature/tag breakdowns, specific test history, or anything derivable from the report
  data. Trigger on phrases like "analyze the serenity report", "how many tests failed", "which
  tests are slowest", "compare v2.4.1 and v2.5.0", "show failed test cases", "why did this test
  fail", "what new failures appeared", "pass rate over last 3 releases", "which feature has most
  failures", "is this test flaky", or any other report-related query. Reports are local JSON
  files in the serenity-reports/ folder — read them directly, no server or network needed.
---

# Serenity BDD Report Analyzer

Teaches Copilot to read and analyze Serenity BDD report JSON files stored locally in this
project, and to answer **any** question the user asks about them. Everything runs inside the
IDE — Copilot reads the files directly from the open workspace. No server, no network.

---

## Where the reports live

```
serenity-reports/
  v2.4.1/
    summary.json        ← aggregate counts + all test results
    results/            ← per-test JSON files (optional, deep detail)
  v2.5.0/
    summary.json
    results/
```

When the user names a version (e.g. "v2.5.0"), read
`serenity-reports/<version>/summary.json`. For "latest", use the highest version folder.
For trend/history questions, read multiple version folders.

---

## summary.json structure

```
summary.json
├── total                       total test count
├── counts
│   ├── SUCCESS                 passed
│   ├── FAILURE                 failed
│   ├── PENDING                 pending
│   └── IGNORED                 skipped / ignored
└── testResults[]
    ├── name                    full test name
    ├── result                  SUCCESS | FAILURE | PENDING | IGNORED
    ├── duration                milliseconds
    ├── tags[]                  { name, type } — "feature"/"story" group tests
    ├── testSteps[]             { description, result, errorMessage }
    └── testFailureCause
        ├── message             assertion / exception text
        └── stackTrace[]        stack frame strings (first line most useful)
```

> Field names vary slightly by Serenity version. If a field is missing, read the actual
> file structure first and adapt — never assume.

---

## Core principle

**Answer ANY question that can be derived from the report data.** The scenarios below are
common patterns, not an exhaustive list. If the user asks something not listed, work out
which fields answer it, read the relevant file(s), compute the answer, and present it
clearly. Always read the actual JSON before answering — never guess counts or results.

---

## Scenario patterns

### A. Counts & rates
- "how many tests failed / passed / are pending in v2.5.0?" → read `counts`.
- "what's the pass rate in v2.5.0?" → `SUCCESS / total * 100`, show as a percentage.
- "how many tests ran in total?" → `total`.
- "give me the full summary / overview / status of v2.5.0" → all counts + pass rate.

### B. Failed test details
- "show / list failed test cases in v2.5.0" → all `testResults` with `result === FAILURE`,
  grouped by feature tag, each with name, duration, error message, first stack line.
- "which tests failed in the Checkout feature?" → filter failures by `tags[].name`.
- "what's the most common failure / error pattern?" → group failures by similar
  `testFailureCause.message` and report the most frequent.

### C. Root cause
- "why did CheckoutFlowTest fail in v2.5.0?" → find the test, show full error message,
  top 3-5 stack trace lines, failed `testSteps`, plus a short plain-English cause.
- "what's the error for <test>?" → show `testFailureCause.message`.
- "which step failed in <test>?" → list `testSteps` where `result === FAILURE`.

### D. Comparison between two versions
- "compare v2.4.1 and v2.5.0" → counts table with deltas + new failures + fixed tests.
- "what new failures appeared in v2.5.0?" → failing in v2.5.0 but not in v2.4.1.
- "what got fixed in v2.5.0?" → failing in v2.4.1 but passing in v2.5.0.
- "did <test> regress between v2.4.1 and v2.5.0?" → compare that test's result in both.

```
## Comparison: v2.4.1 → v2.5.0
| Metric  | v2.4.1 | v2.5.0 | Δ   |
|---------|--------|--------|-----|
| Total   | 120    | 122    | +2  |
| Passed  | 105    | 110    | +5  |
| Failed  | 12     | 9      | -3  |
| Pending | 3      | 3      | —   |

### New failures in v2.5.0
- <test name>: <error message>
### Fixed in v2.5.0
- <test name>
```

### E. Trends across 3+ versions
- "is the pass rate improving over the last 3 releases?" → read each version's `counts`,
  show pass rate per version as a small table or trend line.
- "how has the failure count changed over time?" → list FAILURE count per version.
- "which tests fail repeatedly across releases?" → find test names that are FAILURE in
  multiple version files (recurring / chronic failures).

### F. Flaky / unstable tests
- "is <test> flaky?" → check the same test across versions; if it alternates
  pass/fail without code intent, flag as potentially flaky.
- "which tests are unstable?" → tests whose `result` changes across consecutive versions.

### G. Performance / duration
- "which tests are slowest in v2.5.0?" → sort `testResults` by `duration` descending,
  show top N in seconds.
- "what's the total execution time?" → sum all `duration` values.
- "which tests take longer than 5 seconds?" → filter `duration > 5000`.
- "did <test> get slower since v2.4.1?" → compare its `duration` across versions.

### H. Feature / tag breakdown
- "which feature has the most failures in v2.5.0?" → group failures by feature tag, rank.
- "how many tests are tagged 'smoke'?" → count tests with that tag.
- "show pass/fail breakdown per feature" → group all tests by feature, show counts.

### I. Search & lookup
- "did <test> pass in v2.5.0?" → find by name, report its `result`.
- "find tests matching 'login'" → filter `testResults` by name substring.
- "list all tests in v2.5.0" → all `testResults` names with their result.
- "what reports / versions do I have?" → list folder names in `serenity-reports/`.

---

## Output rules

- Read the actual file(s) before every answer — never guess.
- If a version folder doesn't exist, say so and list the versions that do exist.
- For comparisons and trends, match tests by their `name` field across files.
- Group by feature tag where it aids readability; rank where the user asks "most/top".
- Convert durations to seconds (`ms / 1000`) for human readability.
- Keep error messages readable — truncate very long ones but keep the meaningful part.
- For "why did it fail" questions, always add a brief root-cause interpretation.
- Use markdown tables for comparisons, counts, and rankings.
