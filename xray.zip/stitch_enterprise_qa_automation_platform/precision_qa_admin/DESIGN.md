---
name: Precision QA Admin
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2151da'
  primary: '#0037b0'
  on-primary: '#ffffff'
  primary-container: '#1d4ed8'
  on-primary-container: '#cad3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#7f2500'
  on-tertiary: '#ffffff'
  tertiary-container: '#a73400'
  on-tertiary-container: '#ffc9b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#0039b5'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59c'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#832700'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-md:
    fontFamily: inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-md:
    fontFamily: inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-md:
    fontFamily: jetbrainsMono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: -0.01em
  code-sm:
    fontFamily: jetbrainsMono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-xxs: 2px
  space-xs: 4px
  space-sm: 8px
  space-md: 12px
  space-lg: 16px
  space-xl: 20px
  space-2xl: 24px
  space-3xl: 32px
  table-row-compact: 28px
  table-row-default: 36px
  sidebar-width: 240px
  sidebar-collapsed: 48px
---

## Brand & Style

This design system establishes a high-density, workflow-centric administrative workspace tailored for software quality engineers, SDETs, and engineering directors. The visual tone is analytical, disciplined, and utilitarian—drawing direct influence from developer-first operational tools like GitHub Enterprise, Linear, and modern CI/CD dashboards.

### Aesthetic Principles
- **Functional Minimalism:** Elimination of decorative distractions. No illustrative gradients, no background blur filters, and no ornamental geometry. Information hierarchy drives aesthetic value.
- **Architectural Rigidity:** Surfaces rely on structural 1px grid divisions (`#E2E8F0` and `#CBD5E1`) rather than volumetric shadow projection. Content blocks behave like precision instruments docked alongside one another.
- **Information Density over Canvas Emptiness:** Whitespace is strictly metered to maximize viewport utility. Tables, tree-views, and diagnostic consoles prioritize compact vertical footprints (28px–36px row heights) to expose deep operational context without superfluous scrolling.
- **Technical Authority:** Color is applied exclusively as a functional signifier: directing focus toward high-priority execution controls, pipeline states, and error vectors.

## Colors

The system operates strictly within a calibrated high-contrast light mode. Light surface tones distinguish system containers and interactive canvases, while crisp slate neutrals anchor content readability across prolonged monitoring sessions.

### Core Canvas & Structure
- **Base Surface (`#FFFFFF`):** Primary canvas for active data grids, cards, modals, and input fields.
- **Subtle Surface Layer (`#F8FAFC`):** Table header bands, read-only sidebar rails, and inactive container fills.
- **Muted Structural Layer (`#F1F5F9`):** Canvas bedrock, breadcrumb ribbons, code block backdrops, and active row hover states.
- **Structural Dividers (`#E2E8F0`):** Default 1px interior boundary for table rows, panel splits, and card containers.
- **Emphasized Dividers (`#CBD5E1`):** Active panel borders, pinned headers, dropdown wrappers, and unfocused form control strokes.

### Semantic & Execution Tokens
- **Primary Action (`#1D4ED8`):** Dominant brand trigger for initiating test runs, executing builds, and key confirmations. Hover state escalates to `#1E40AF`; pressed state lands on `#172554`. Focus rings mandate `rgba(29, 78, 216, 0.2)` with a 2px offset.
- **Success / Passed (`#059669` / bg `#ECFDF5` / border `#A7F3D0`):** Applied exclusively to validated test suites, green assertions, and healthy service integrations.
- **Danger / Failed (`#E11D48` / bg `#FFF1F2` / border `#FECDD3`):** Uncompromising red reserved for failed assertions, pipeline crashes, and destructive purge operations.
- **Warning / Flaky / Pending (`#D97706` / bg `#FFFBEB` / border `#FDE68A`):** Indicates running pipelines, intermittent flaky test indicators, and non-blocking warnings.
- **Neutral / Skipped / Draft (`#475569` / bg `#F1F5F9` / border `#CBD5E1`):** Inactive tests, skipped assertions, scheduled dry-runs, and drafted test plans.

## Typography

Typography is calibrated for extreme legibility in complex, data-heavy views. The system combines **Inter** for clean UI hierarchy with **JetBrains Mono** for all operational syntax: test run IDs, assertion traces, timing benchmarks, git commit hashes, and JSON diffs.

### Hierarchy & Scale Rules
- **Display Restraint:** Font sizes cap at 24px within administrative consoles. Primary page headers use `headline-xl` (`24px/32px`), secondary module headers use `headline-lg` (`18px/24px`), and table or sub-pane headers leverage `headline-sm` (`14px/20px`).
- **Data Densities:** Standard body copy is locked at `13px` (`body-md`) with 18px line height. Compact grid rows, inline metadata, and secondary status annotations shift down to `12px` (`body-sm`) to maximize visible records.
- **Monospace Integration:** Every test run identifier (e.g., `TR-8492`), payload key, timestamp, and duration (e.g., `124ms`) renders strictly via `jetbrainsMono`. Tabular figures (`tnum`) must remain active across both fonts to prevent horizontal table jittering during live re-renders.

## Layout & Spacing

Layouts follow a docked, pane-oriented structure. The top chrome houses global project contexts and environment pickers, while a collapsible 240px left-hand navigation pane controls deep test hierarchy drill-downs.

### Grid Architecture
- **Fluid Structural Shell:** The central viewport employs a 100% fluid grid layout, bound inside modular panels. Outer dashboard frames use fixed 16px gutter margins (`space-lg`), eliminating wide empty guttering typical of consumer web apps.
- **Split-Pane Resizing:** Run execution views and automated trace views leverage horizontal or vertical two-pane splits (e.g., 60% test case ledger, 40% assertion console & step breakdown) bound by draggable 1px partition handles.
- **Responsive Adaptations:**
  - **Desktop Large (>= 1440px):** Full sidebars remain pinned; dual-pane trace inspection consoles render side-by-side.
  - **Desktop Compact (1024px – 1439px):** Left sidebar automatically collapses to icon-only mode (48px); log inspection trays dock to the bottom with vertical split tabs.
  - **Tablet / Read-Only (< 1024px):** Inspection views stack sequentially; table structures transition to horizontally scrollable viewports with pinned test-name columns.

## Elevation & Depth

This design system avoids blurry drop shadows, heavy lighting metaphors, and layered blur effects. Visual elevation and spatial layer hierarchy are maintained strictly through borders, tonal background shifts, and single-pixel micro-rules.

### Architectural Rules
- **Flat 1px Enclosures:** Cards, sidebars, data grids, and filter bars rely entirely on 1px solid outlines in `#E2E8F0` or `#CBD5E1`.
- **Tonal Stepping for Depth:** Modals and flyout drawer panels sit on pure `#FFFFFF` over a subtle low-opacity scrim (`rgba(15, 23, 42, 0.4)`), bounded by an authoritative 1px `#CBD5E1` border. 
- **The 1px Utility Shadow:** Floating components that temporarily break the plane (e.g., autocomplete popovers, select dropdown menus, and quick-filter trays) utilize an ultra-subtle 1px micro-border combined with a minimal structural shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.05)`. Floating overlays do not exceed this threshold.
- **Active Selection Tiers:** Hover states on rows and items step from `#FFFFFF` down to `#F8FAFC`. Selected or focused rows adopt `#F1F5F9` along with a 2px solid `#1D4ED8` inset indicator line along the left edge.

## Shapes

Shapes reflect precision engineering. Corner radii are tightly controlled to emphasize an exacting, technical interface.

### Radius Scaling
- **Subtle Corner Profile (`roundedness: 1`):** Core interactive triggers, input fields, dropdown toggles, and status badges take a `4px` (`0.25rem`) radius.
- **Containers & Shells:** Cards, modals, code blocks, and data-grid wrappers feature `6px` or `8px` (`rounded-lg`) outer bounds, pairing with internal item radii of `4px` to preserve concentric geometry.
- **Pills and Full Circles:** Prohibited for broad administrative containers. Circular geometry is reserved strictly for test status bullet points (6px indicator dots) and user profile avatars (20px–24px).

## Components

### Buttons
- **Primary:** Background `#1D4ED8`, text `#FFFFFF`, border `1px solid #1D4ED8`, 4px radius. Height: 32px (standard) or 26px (compact table action). Hover: `#1E40AF`.
- **Secondary / Outline:** Background `#FFFFFF`, text `#0F172A`, border `1px solid #CBD5E1`, 4px radius. Hover: `#F8FAFC`, border `#94A3B8`.
- **Ghost:** Background transparent, text `#334155`, no border. Hover: `#F1F5F9`, text `#0F172A`.
- **Destructive:** Background `#FFF1F2`, text `#E11D48`, border `1px solid #FECDD3`. Hover: background `#FFE4E6`.

### Badges & Status Indicators
- Status badges feature a compact, non-intrusive footprint: 20px height, 4px radius, 6px horizontal padding.
- Consists of a 6px solid circular dot preceding an uppercase `label-md` font string.
  - **Passed:** Dot `#059669`, background `#ECFDF5`, border `1px solid #A7F3D0`, text `#065F46`.
  - **Failed:** Dot `#E11D48`, background `#FFF1F2`, border `1px solid #FECDD3`, text `#9F1239`.
  - **Flaky / Running:** Dot `#D97706`, background `#FFFBEB`, border `1px solid #FDE68A`, text `#92400E`.
  - **Skipped:** Dot `#64748B`, background `#F8FAFC`, border `1px solid #E2E8F0`, text `#475569`.

### Data Grids & Tables
- **Header:** Height 32px, background `#F8FAFC`, border-bottom `1px solid #CBD5E1`. Text style: `label-md`, color `#475569`, uppercase.
- **Rows:** Alternating clean backgrounds (`#FFFFFF`), row height locked at 32px (dense) or 40px (spacious). Border-bottom: `1px solid #E2E8F0`. Hover: `#F8FAFC`.
- **Cells:** Alignment is left-anchored for titles, right-anchored for numeric durations and timestamps. Code identifiers (e.g. `spec.ts:142`) render in `code-sm` with color `#334155`.

### Input Fields & Search Bars
- Background `#FFFFFF`, 1px solid border `#CBD5E1`, 4px radius, height 32px, text `body-md` (`#0F172A`).
- **Placeholder:** `#94A3B8`.
- **Focus State:** 1px solid border `#1D4ED8`, zero-spread shadow `box-shadow: 0 0 0 1px #1D4ED8`.

### Checkboxes & Selectors
- Checkbox footprint: 14px x 14px, 2px radius, border `1px solid #94A3B8`, background `#FFFFFF`.
- **Checked State:** Background `#1D4ED8`, border `#1D4ED8`, check icon rendered in `#FFFFFF`.

### Test Execution Tracing Trays & Code Blocks
- Dark-free, light-mode native code frames. Background `#F8FAFC`, border `1px solid #E2E8F0`, 4px radius.
- Code text format: `code-md`, text `#0F172A`. Line numbers anchored in `#94A3B8` with a 1px border-right `#E2E8F0`.
- Assertion failure highlights apply a `#FFF1F2` row tint with an active left border `2px solid #E11D48`.