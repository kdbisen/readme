# Serenity BDD AI Agent — Local Reports

A GitHub Copilot Custom Agent (`@serenity-ai`) that reads Serenity BDD reports
stored on your **local machine** and answers natural-language QA queries from
IntelliJ's Copilot Chat panel.

No CI/CD. No GitHub repo. No cloud. Just your local JSON files.

> Full implementation code → `SKILL.md`

---

## What it can do

| Query in Copilot Chat | What you get |
|---|---|
| `@serenity-ai what versions do I have?` | Lists all locally saved report versions |
| `@serenity-ai summary for v2.5.0` | Pass / fail / pending counts |
| `@serenity-ai how many tests failed in v2.5.0?` | Failure count + test names |
| `@serenity-ai show failed test cases in v2.5.0` | Full detail per failure — error, stack, duration, grouped by feature |
| `@serenity-ai compare v2.4.1 vs v2.5.0` | Side-by-side table + new regressions + fixed tests |
| `@serenity-ai why did CheckoutFlowTest fail in v2.5.0?` | Error message + stack trace + failed steps |

---

## How reports are stored locally

After each test run, a small save script copies Serenity output into a versioned folder:

```
~/serenity-reports/
  v2.4.1/
    summary.json      ← aggregate counts + all test results
    results/          ← individual test JSON files
  v2.5.0/
    summary.json
    results/
```

Run `./save-report.sh v2.5.0` after `mvn verify`.
Script and setup → `SKILL.md → Save script`.

---

## Setup (3 steps)

1. **Save reports locally** — run `save-report.sh <version>` after each test run.
   Full script in `SKILL.md → Save script`.

2. **Start the agent server** — `npm install && node index.js`.
   Reads from `SERENITY_REPORTS_DIR` in `.env`.
   Full server code in `SKILL.md → index.js`.

3. **Expose + register** — use `ngrok http 3000` to get an HTTPS URL,
   then register a GitHub App as a Copilot Extension pointing at that URL.
   Steps in `SKILL.md → Register as GitHub Copilot Extension`.

---

## Token usage

| File | Audience | Token cost |
|---|---|---|
| `agent.md` (this file) | Human — read once for orientation | Minimal — no code |
| `SKILL.md` | Copilot — loaded when generating or extending the agent | Full code, loaded on demand |

---

## Files in this project

```
serenity-agent/
├── agent.md          ← this file (human orientation guide)
├── SKILL.md          ← full AI instructions + all code
├── index.js          ← local Express server (port 3000)
├── handlers/
│   ├── compare.js    ← compare two local release summaries
│   ├── failures.js   ← show failed tests grouped by feature
│   └── query.js      ← route single-release questions
├── lib/
│   └── local.js      ← read summary.json from local disk (no network)
├── save-report.sh    ← copy Serenity output into versioned folder
└── .env              ← SERENITY_REPORTS_DIR, APP_SECRET, PORT
```
