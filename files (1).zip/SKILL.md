---
name: serenity-bdd-ai-agent
description: >
  Use this skill to build or extend a GitHub Copilot Custom Agent (@serenity-ai) that reads
  Serenity BDD report JSON files stored locally on the developer's machine and answers
  natural-language questions about test failures, comparisons, and root causes — directly
  from IntelliJ's Copilot Chat panel. Trigger when the user wants to query local Serenity
  reports, compare versions, list failed tests, or understand failure reasons without any
  CI/CD pipeline or GitHub repo involvement.
---

# Serenity BDD AI Agent — Local Reports

Builds a GitHub Copilot Custom Agent that reads **locally stored** Serenity BDD report JSON
files and answers natural-language QA queries from IntelliJ's Copilot Chat panel.

No CI/CD. No GitHub repo storage. No cloud. Reports stay on your machine.

---

## How local report storage works

You run Serenity tests locally and save reports by version into one root folder:

```
~/serenity-reports/
  v2.4.1/
    summary.json
    results/
      LoginTest.json
      CheckoutTest.json
  v2.5.0/
    summary.json
    results/
      LoginTest.json
      CheckoutTest.json
```

Run the save script after each test run, then query via `@serenity-ai` in IntelliJ.

---

## Save script (save-report.sh)

Run this after every `mvn verify` to snapshot the report into the right version folder:

```bash
#!/bin/bash
# save-report.sh
VERSION=${1:-"unversioned"}
DEST="$HOME/serenity-reports/$VERSION"
SRC="target/site/serenity"

mkdir -p "$DEST/results"
cp "$SRC/summary.json"   "$DEST/summary.json"
cp "$SRC/results/"*.json "$DEST/results/"

echo "Saved → $DEST"
```

Usage:
```bash
chmod +x save-report.sh
./save-report.sh v2.5.0
```

---

## Project structure

```
serenity-agent/
  index.js            ← Express server (runs locally, port 3000)
  handlers/
    compare.js        ← diff two local release summaries
    failures.js       ← list failed tests grouped by feature
    query.js          ← route single-release questions
  lib/
    local.js          ← read JSON files directly from local disk
  .env                ← SERENITY_REPORTS_DIR, APP_SECRET, PORT
  package.json
```

---

## lib/local.js — read from disk (no network, no auth)

```js
import fs   from 'fs';
import path from 'path';

const BASE = process.env.SERENITY_REPORTS_DIR
  ?? path.join(process.env.HOME, 'serenity-reports');

export function listVersions() {
  return fs.readdirSync(BASE)
    .filter(d => fs.statSync(path.join(BASE, d)).isDirectory())
    .sort();
}

export function resolveVersion(version) {
  if (version && version !== 'latest') return version;
  const all = listVersions();
  if (!all.length) throw new Error(`No reports found in ${BASE}`);
  return all.at(-1);         // latest = last alphabetically (works for v-prefixed semver)
}

export function fetchSummary(version) {
  const v    = resolveVersion(version);
  const file = path.join(BASE, v, 'summary.json');
  if (!fs.existsSync(file))
    throw new Error(`Report not found: ${file}. Available versions: ${listVersions().join(', ')}`);
  return { version: v, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
}

export function fetchAllResults(version) {
  const v   = resolveVersion(version);
  const dir = path.join(BASE, v, 'results');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.json'))
    .flatMap(f => {
      try { return [JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'))]; }
      catch { return []; }
    });
}
```

---

## index.js — local Express server

```js
import 'dotenv/config';
import express from 'express';
import crypto  from 'crypto';
import { handleQuery }   from './handlers/query.js';
import { handleCompare } from './handlers/compare.js';

const app = express();
app.use(express.json());

function verifySignature(req, res, next) {
  const sig      = req.headers['x-hub-signature-256'] ?? '';
  const expected = 'sha256=' + crypto.createHmac('sha256', process.env.APP_SECRET ?? '')
                                     .update(JSON.stringify(req.body)).digest('hex');
  if (sig !== expected) return res.status(401).send('Unauthorized');
  next();
}

app.post('/agent', verifySignature, async (req, res) => {
  const message  = req.body.messages.at(-1).content;
  const versions = message.match(/v?\d+\.\d+[\.\d]*/g) ?? [];
  const isCompare = /compare|vs|versus|difference|delta/i.test(message);

  try {
    const reply = isCompare && versions.length >= 2
      ? await handleCompare(versions[0], versions[1])
      : await handleQuery(message, versions[0] ?? 'latest');
    res.json({ role: 'assistant', content: reply });
  } catch (err) {
    res.json({ role: 'assistant', content: `⚠️ ${err.message}` });
  }
});

const PORT = process.env.PORT ?? 3000;
app.listen(PORT, () => console.log(`Serenity agent → http://localhost:${PORT}`));
```

---

## handlers/query.js

```js
import { fetchSummary } from '../lib/local.js';
import { showFailures }  from './failures.js';

export async function handleQuery(message, version) {
  const summary  = fetchSummary(version);
  const failures = (summary.testResults ?? []).filter(t => t.result === 'FAILURE');

  // "show / list / see / view / display failed test cases"
  if (/show|list|see|display|view/i.test(message) && /fail/i.test(message)) {
    return showFailures(failures, summary.version);
  }

  // "how many failed / failure count / number of failures"
  if (/how many|count|number of/i.test(message) && /fail/i.test(message)) {
    return `**${summary.version}** — **${failures.length} failing** out of ${summary.total} total.\n\n` +
      failures.slice(0, 10).map(t => `- ${t.name}`).join('\n') +
      (failures.length > 10 ? `\n_...and ${failures.length - 10} more._` : '');
  }

  // "why did X fail / reason / error / cause"
  if (/why|reason|cause|error/i.test(message)) {
    const name  = extractTestName(message);
    const match = failures.find(t => t.name.toLowerCase().includes(name.toLowerCase()));
    return match
      ? formatSingleFailure(match, summary.version)
      : `No test matching "${name}" found in ${summary.version}. Try a partial name.`;
  }

  // "list versions / what versions do I have"
  if (/version|available|list.*report/i.test(message)) {
    const { listVersions } = await import('../lib/local.js');
    return `Available local versions:\n${listVersions().map(v => `- ${v}`).join('\n')}`;
  }

  // Default: release summary
  return `**${summary.version} report**
- Total:   ${summary.total}
- Passed:  ${summary.counts?.SUCCESS  ?? 0}
- Failed:  ${summary.counts?.FAILURE  ?? 0}
- Pending: ${summary.counts?.PENDING  ?? 0}
- Skipped: ${summary.counts?.IGNORED  ?? 0}`;
}

function extractTestName(msg) {
  const m = msg.match(/["'](.+?)["']|test\s+(\S+)/i);
  return m?.[1] ?? m?.[2] ?? '';
}

function formatSingleFailure(test, version) {
  const steps = (test.testSteps ?? [])
    .filter(s => s.result === 'FAILURE')
    .map(s => `  - ${s.description}: ${s.errorMessage ?? 'N/A'}`)
    .join('\n');
  return `## ${test.name}
**Version:** ${version} | **Duration:** ${(test.duration / 1000).toFixed(2)}s

### Error
\`\`\`
${test.testFailureCause?.message ?? 'None recorded'}
\`\`\`

### Stack trace (top 3)
\`\`\`
${(test.testFailureCause?.stackTrace ?? []).slice(0, 3).join('\n') || 'N/A'}
\`\`\`

### Failed steps
${steps || '_No step detail available_'}`;
}
```

---

## handlers/failures.js — show failed test cases grouped by feature

```js
export function showFailures(failures, version) {
  if (!failures.length) return `✅ No failures in **${version}**.`;

  const grouped = {};
  for (const t of failures) {
    const feature = t.tags?.find(g => g.type === 'feature')?.name ?? 'Untagged';
    (grouped[feature] ??= []).push(t);
  }

  const sections = Object.entries(grouped).map(([feature, tests]) => {
    const rows = tests.map((t, i) => {
      const err = t.testFailureCause?.message ?? 'No error captured';
      const dur = t.duration ? `${(t.duration / 1000).toFixed(2)}s` : 'N/A';
      const at  = t.testFailureCause?.stackTrace?.[0] ?? '';
      return [
        `#### ${i + 1}. ${t.name}`,
        `- **Duration:** ${dur}`,
        `- **Error:** \`${err.slice(0, 120)}${err.length > 120 ? '…' : ''}\``,
        at ? `- **At:** \`${at}\`` : '',
      ].filter(Boolean).join('\n');
    });
    return `### Feature: ${feature} (${tests.length} failure${tests.length > 1 ? 's' : ''})\n\n${rows.join('\n\n')}`;
  });

  return [
    `## Failed test cases — ${version}`,
    `**Total failures: ${failures.length}**\n`,
    sections.join('\n\n---\n\n'),
    `\n_Drill in: \`@serenity-ai why did <test name> fail in ${version}?\`_`,
  ].join('\n');
}
```

---

## handlers/compare.js — diff two local versions

```js
import { fetchSummary } from '../lib/local.js';

export async function handleCompare(v1, v2) {
  const s1 = fetchSummary(v1);
  const s2 = fetchSummary(v2);

  const newFails = (s2.testResults ?? []).filter(t =>
    t.result === 'FAILURE' &&
    !(s1.testResults ?? []).some(f => f.name === t.name && f.result === 'FAILURE')
  );
  const fixed = (s1.testResults ?? []).filter(t =>
    t.result === 'FAILURE' &&
    (s2.testResults ?? []).some(f => f.name === t.name && f.result !== 'FAILURE')
  );
  const d = (a, b) => { const n = b - a; return (n > 0 ? '+' : '') + n; };

  return `## Comparison: ${v1} → ${v2}

| Metric   | ${v1} | ${v2} | Δ |
|----------|-------|-------|---|
| Total    | ${s1.total} | ${s2.total} | ${d(s1.total, s2.total)} |
| Passed   | ${s1.counts?.SUCCESS ?? 0} | ${s2.counts?.SUCCESS ?? 0} | ${d(s1.counts?.SUCCESS ?? 0, s2.counts?.SUCCESS ?? 0)} |
| Failed   | ${s1.counts?.FAILURE ?? 0} | ${s2.counts?.FAILURE ?? 0} | ${d(s1.counts?.FAILURE ?? 0, s2.counts?.FAILURE ?? 0)} |
| Pending  | ${s1.counts?.PENDING ?? 0} | ${s2.counts?.PENDING ?? 0} | — |

### 🔴 New failures in ${v2} (${newFails.length})
${newFails.length
  ? newFails.map(t => `- **${t.name}**: \`${t.testFailureCause?.message ?? 'see report'}\``).join('\n')
  : '_None — no new regressions_'}

### ✅ Fixed in ${v2} (${fixed.length})
${fixed.length ? fixed.map(t => `- ${t.name}`).join('\n') : '_None_'}`;
}
```

---

## .env

```
SERENITY_REPORTS_DIR=/Users/yourname/serenity-reports
APP_SECRET=your_copilot_webhook_secret
PORT=3000
```

---

## Expose local server to GitHub (tunnel — required for webhook)

GitHub Copilot needs an HTTPS URL to send messages to your local agent.
Pick any tunnel tool — no install needed for the quick options:

```bash
# ngrok (most common, free tier)
ngrok http 3000

# Cloudflare (no account needed for quick test)
cloudflared tunnel --url http://localhost:3000

# VS Code dev tunnels
devtunnel host -p 3000
```

Paste the HTTPS URL as the **Webhook URL** when registering the GitHub App.
The tunnel URL changes on restart — update the GitHub App webhook URL when it does.

---

## Register as GitHub Copilot Extension

1. **github.com → Settings → Developer Settings → GitHub Apps → New GitHub App**
2. Fill in:
   - **App name:** `serenity-ai`
   - **Webhook URL:** `https://<tunnel-url>/agent`
   - **Webhook secret:** same as `APP_SECRET` in `.env`
3. **Permissions:** Account → Copilot Chat → Read and write
4. **Copilot tab** → type: Copilot Extension, enable chat
5. Install on your personal GitHub account

---

## Use in IntelliJ Copilot Chat

Open **Tools → GitHub Copilot → Open Copilot Chat**, then:

```
@serenity-ai what versions do I have?
@serenity-ai summary for v2.5.0
@serenity-ai how many tests failed in v2.5.0?
@serenity-ai show failed test cases in v2.5.0
@serenity-ai compare v2.4.1 vs v2.5.0
@serenity-ai why did CheckoutFlowTest fail in v2.5.0?
```

---

## Supported query types

| Query intent | Trigger phrases | Handler |
|---|---|---|
| List local versions | "what versions", "available reports" | `query.js` |
| Release summary | "summary", "overview", "status" | `query.js` |
| Failure count | "how many failed", "count failures" | `query.js` |
| Show failed test details | "show failed", "list failures", "see failed test cases" | `failures.js` |
| Single test root cause | "why did X fail", "reason", "error in X" | `query.js` |
| Release comparison | "compare", "vs", "difference", "delta" | `compare.js` |
| New regressions | "new failures", "newly failing" | `compare.js` |
| Fixed tests | "fixed", "resolved", "now passing" | `compare.js` |

---

## Serenity summary.json fields used

```
summary.json
├── total
├── counts { SUCCESS, FAILURE, PENDING, IGNORED }
└── testResults[]
    ├── name
    ├── result           SUCCESS | FAILURE | PENDING | IGNORED
    ├── duration         milliseconds
    ├── tags[]           { name, type }   ← "feature" type used for grouping
    └── testFailureCause
        ├── message      assertion / exception text
        └── stackTrace[] array of stack frame strings
```

Verify your field names before running:
```bash
python3 -m json.tool ~/serenity-reports/v2.5.0/summary.json | head -60
```
